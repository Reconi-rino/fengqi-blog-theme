import{c as e,s as r}from"./flowDiagram-UKHOOZJN-XwRRjJOE.js";import{_ as a}from"./index-CEkAh5vr.js";import"./chunk-5VM5RSS4-C8xMyMvS.js";import"./chunk-XXDRQBXY-CLvMF5iM.js";import"./chunk-KBJHAD2P-BC5vAVqG.js";import"./chunk-2GRJ4B5K-os7v3PcO.js";import"./channel-CKY7mgdL.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
